// ============================================================
// BOOKFLOW AI — COMPLETE KNOWLEDGE BASE
// עודכן לפי כל ההחלטות שהתקבלו
// כל הסוכנים קוראים מכאן. עדכן פה = כל הסוכנים מתעדכנים.
// ============================================================

export const KNOWLEDGE_BASE = `
== BOOKFLOW AI — COMPLETE KNOWLEDGE BASE ==

---

## 1. PRODUCT OVERVIEW

BookFlow AI is an AI-powered appointment setter for inbound sales teams.
It answers every inbound lead in under 10 seconds via voice call, handles objections,
qualifies the lead, and books a meeting directly into the calendar — 24/7/365, automatically.

Domain: https://bookflow-ai.com
Repository: https://github.com/bookflowk-ui/BookFlow-AI

Core value proposition:
"You paid for that lead. By the time you picked up the phone, your competitor already closed them.
BookFlow AI picks up every inbound lead — weekends, holidays, 3am — so you stop losing deals you already paid for."

Key stat: Calling a lead in under 10 seconds converts up to 4x higher than calling after 30 minutes.
Setup time: 15 minutes, no developer needed.

---

## 2. PRICING MODEL

Model: Subscription with hard monthly caps. NOT pay-as-you-go.
Delayed billing: Card collected upfront, charged after 14 days.
Free trial: 14 days, 60 AI minutes, no charge until day 14. Reminder sent on day 12.
Annual discount: 20% off monthly price.

| Plan       | Monthly  | Minutes | Leads/month    | Max bill   | Overage    |
|------------|----------|---------|----------------|------------|------------|
| Solo       | $99/mo   | 200     | ~80–100        | $184/mo    | $0.68/min  |
| Business ⭐| $349/mo  | 500     | ~200–250       | $549/mo    | $0.45/min  |
| Agency     | $899/mo  | 1,500   | ~600–750       | $1,299/mo  | $0.42/min  |
| Enterprise | $2,599/mo| 3,600   | ~1,400–1,800   | $3,599/mo  | $0.40/min  |

Pay-per-use option: $0.45/min (no commitment) — shown below all plans.

Key positioning:
"We cap every bill. No charges beyond your plan's cap — ever. Zero surprise bills, guaranteed."
"200 minutes of AI calling — enough for ~80–100 leads/month." (language used for all plans)

Overage logic: maxMonthlyUsd = priceUsd + overageCapUsd. Never billed more than max. Ever.

Unit economics (internal):
- Cost per minute: $0.20
- Gross margin at base usage: ~70%
- Break-even for $10K/month salary: 48 Business customers
- MRR at 100 customers (avg $800 mix): ~$80,000
- Monthly fixed costs: ~$400–600 (infra, tools, Twilio, ElevenLabs, Paddle 2.9%)

---

## 3. TARGET CUSTOMER (AVATAR)

Who: Business owner or sales manager, 32–55 years old, male, US-based.
Pays $15–$80 per lead via paid ads.
Has a team (or IS the team) that calls leads back.
He's a closer, not a marketer or developer.
Measures everything in deals and dollars.
Checks his phone at 11pm to see if anyone booked.

Core pain: "I paid for that lead. I just couldn't get to the phone fast enough."

What keeps him up at night:
- Money: Leads cost $15–80. When cold = money gone forever. No idea how many slipped through.
- Time: Leads arrive nights/weekends/holidays — nobody there. Campaign spikes = team overwhelmed.
- Competition: Competitor answered first. That's why he lost the deal. Not price. Not product. Speed.
- People: SDR costs $5,000+/mo, quits after 3 months, has bad days, needs training, has sick days.
- Exhaustion: Tired. Frustrated. Watches money walk out the door. Tired of chasing.

What he wants:
- Wake up to booked meetings without doing anything
- Never miss a lead because of response time again
- Pay one flat predictable price — no surprises
- See every conversation — what was said, what was booked
- Stop depending on people who quit, get sick, have bad days
- Compete with bigger companies by responding faster

Priority avatars:
#1 Solar Sales Manager — 35–50, TX/AZ/FL/CA, 300–2,000 leads/mo, deal $8–15K, 3–10 SDRs on salary
   Pain: "400 Facebook leads this week. Team called 200. Other 200 went cold — $2M in potential gone."
   Hook: "What happens to your leads after 6pm?"
   Plan: Agency ($899) or Enterprise ($2,599)

#2 GoHighLevel Agency Owner — 28–42, remote US, 10–80 clients, wants white-label to resell
   Pain: "Clients ask why leads aren't converting. I need something I can resell at margin."
   Hook: "Do any of your clients struggle with lead response time?"
   Plan: Agency white-label ($899+)
   Value: 1 agency = 10–50 end clients

#3 Mortgage Broker — 38–55, CA/FL/TX, 50–300 leads/mo, deal $3–8K, 1–5 loan officers
   Pain: "Lead fills 3 forms simultaneously. Whoever calls first wins. I'm always third."
   Hook: "Leads fill out 3 forms at once. Who calls them first?"
   Plan: Business ($349)

#4 Home Services (HVAC/Roofing/Plumbing) — 40–58, Midwest/Southeast, 30–200 leads/mo, deal $5–50K
   Pain: "Team on roofs all day. Lead calls, nobody picks up. They call next guy on Google."
   Hook: "What happens when a lead calls while your team is on a job?"
   Plan: Solo ($99) or Business ($349)

---

## 4. COPY & TONE RULES

1. Lead with cost of inaction, not features.
   BAD: "BookFlow AI uses advanced voice technology..."
   GOOD: "Every lead you don't call in 10 seconds is already talking to your competitor."

2. Money math obvious and fast.
   "One extra deal per month pays for the entire year."

3. Speak to emotional exhaustion — not just logic.
   "Stop losing deals to whoever answers the phone first."

4. Use "every" constantly.
   Every lead. Every call. Every meeting. Every time.

5. Zero-risk language.
   "14 days free. Cancel in one click before day 14 — we'll remind you on day 12."

6. Loss frame over gain frame (2.5x more powerful).
   BAD: "You'll save $47,000/year"
   GOOD: "You're losing $X every month right now. BookFlow stops the bleeding for $99/mo."

7. Contrast — make the comparison obvious.
   Human setter: $5,000+/mo, 8hrs/day, quits after 3 months.
   BookFlow AI: $99/mo, 24/7/365, never quits.

8. End with forward motion, not summary.
   "What would 10 extra meetings a month do for your business?"

Tone: Direct. No fluff. Confident not arrogant. Empathetic. Urgent not pushy.
Short sentences. One idea per line. Write to ONE person, not a crowd.

Power words: every, instantly, never, while you sleep, already booked, right now.

---

## 5. KEY MESSAGES

Hero headline: "Every lead you don't call in 10 seconds is already talking to your competitor."
Pain hook: "You paid for that lead. By the time you picked up the phone, your competitor already closed them."
Solution: "BookFlow calls every lead the moment they fill out your form. While you sleep."
CTA: "Wake up tomorrow with meetings already booked."
ROI: "One extra deal per month pays for the entire year."
Fear of missing out: "Right now, while you're reading this, a lead from your last campaign is waiting for a callback."

---

## 6. OBJECTION HANDLING

"Too expensive"
→ One closed deal pays for the whole year. What's one deal worth to you?

"Will leads know it's AI?"
→ Most won't. We disclose anyway — required in most US states, actually builds trust.
  AI transfers to human the instant lead asks.

"Leads hang up"
→ Hang-up rates lower than human SDR calls. AI never sounds tired, pushy, or like it's reading a script.

"We already have a team"
→ Your team sleeps. Leads don't. BookFlow handles nights, weekends, holidays.

"Different from chatbots?"
→ Real phone call in under 10 seconds. Voice converts 3–5x better than chat.
  Think of us as the SDR team Intercom Fin cannot be.

"What if it says the wrong thing?"
→ You write the guardrails. What it can/cannot say, what to escalate, exact pricing to quote.
  Tweak once = applies to every future call instantly.

"TCPA compliance?"
→ Identity disclosure every call, recording consent in two-party states, DNC scrubbing, instant opt-out.
  Your job: collect prior written consent on forms. We handle the rest.

---

## 7. COMPETITORS

| Competitor | Price    | Type              | Weakness                          |
|------------|----------|-------------------|-----------------------------------|
| Bland AI   | $0.09/min| Developer-only    | Hidden fees, no ready solution    |
| Synthflow  | $0.11/min| General platform  | Not appointment-focused, robotic  |
| Retell AI  | $0.07–0.31/min | Developer API | Healthcare-focused, complex setup |
| Setter AI  | $99/mo   | Similar product   | Fewer features, less polished     |
| Vapi       | $0.05+/min | Developer      | Multiple hidden fees, not no-code |

Our edge:
- Ready in 15 minutes — no developer, no setup call
- Hard monthly cap — zero surprise bills guaranteed
- Live voice demo on homepage — no signup needed
- Pain-first copywriting — speaks to the closer, not the techie
- Native WhatsApp + SMS confirmation (Business plan+)

---

## 8. MARKETING STRATEGY

Current status: 0 paying customers. $300 marketing budget. No social media yet.

Primary channel: LinkedIn DMs (10–15/day from personal profile)
Order of approach: Solar first → GHL agencies → Mortgage → Home Services

Daily workflow (1–2 hours):
- Morning 30 min: Send 10–15 LinkedIn DMs
- Afternoon 30 min: Reply to Facebook groups, follow up
- Evening 30 min: Create one piece of content

Weekly targets:
75 DMs sent → 7–14 replies → 2–4 demos → 1 paying customer

Demo offer: "Give me your phone number — watch AI call you in 10 seconds." Cost: $0.60.
Trial offer: 5 real leads only (NOT 200). Cost to us: $3.
Follow-up rule: One follow-up after 5 days. Never more.

Facebook groups to join:
- GoHighLevel Official Community (100K+ members)
- Solar Sales & Marketing Professionals
- Mortgage Brokers Network
- HVAC Contractors USA

Content strategy:
- LinkedIn 3x/week: Monday demo video, Wednesday pain post, Friday ROI/case study
- YouTube Shorts + LinkedIn video: 60-sec screen recording, no face needed
- Hook formula: [Pain] → [Surprising stat] → [Implication] → CTA
- Max 3 hashtags. No corporate speak. Hook in line 1.
- Best time to post: 8–9am EST weekdays.

LinkedIn DM templates:
Solar: "Hey [Name] — saw you're running sales at [Company]. What happens to your inbound leads after 6pm? I built something that calls every lead in under 10 seconds, 24/7. No pitch, just curious what your current process looks like."
GHL: "Hey [Name] — saw you're running a GHL agency. Do any of your clients struggle with lead response time? I built a white-label AI appointment setter that integrates natively with GHL. Happy to show you a 5-min demo."
Mortgage: "Hi [Name] — leads fill out forms on 3 different sites at the same time, whoever calls first wins. I built an AI that calls every inbound lead in under 10 seconds. Worth a 10-minute chat?"
Follow-up: "Hey [Name] — just wanted to bump this up. Even a quick 'not relevant right now' is helpful. Thanks either way."

---

## 9. TECH STACK

Framework: Next.js 14.1.0 (App Router), TypeScript, Tailwind CSS
Database: Supabase (PostgreSQL + Auth + RLS)
Payments: Paddle (subscription billing) — NOT YET CONNECTED
Voice AI demo: ElevenLabs Conversational AI (@elevenlabs/react SDK)
Voice AI calls: Retell AI
Email: Resend (transactional) — NOT YET CONNECTED
Hosting: Vercel
Calendar: Google Calendar OAuth + Microsoft/Outlook OAuth — NOT YET CONFIGURED
CRMs: HubSpot, Salesforce, GoHighLevel
Automation: Zapier, Make, Slack, WhatsApp
WhatsApp agents: Twilio + Upstash Redis + Anthropic Claude API

Fonts: Plus Jakarta Sans (body), Space Grotesk (display), JetBrains Mono (mono)
Brand color: Cyan #22d3ee | CTA gradient: #22d3ee → #3b82f6 | Background: #020817

---

## 10. KNOWN ISSUES / CURRENT STATE

1. Paddle NOT connected — checkout/billing broken until real credentials added
2. Resend NOT connected — no transactional emails yet
3. ElevenLabs free tier — 15 min/month quota. Demo stops when exhausted.
4. No real customers yet — all testimonials are placeholder
5. Google/Microsoft Calendar OAuth not configured
6. Demo.tsx is dead code — voice demo now lives in Hero.tsx
7. WhatsApp agents not yet deployed — being built now

---

## 11. KEY DECISIONS MADE

1. Subscription over PAYG — predictability. "Flat price, hard cap, no surprises."
2. Delayed billing — card collected upfront, charged after 14 days. Reminder on day 12.
3. Minutes presented as leads — "~80–100 leads/month" not "200 minutes"
4. Pay-per-use option ($0.45/min) added below plans — lowers entry barrier
5. Agency price raised $799→$899, Enterprise raised $2,299→$2,599 — better margins
6. Voice demo in Hero — single button, no separate section, no iPhone frame
7. Pain-first copy — loss framing throughout, not features
8. No fake testimonials — "From the founders" until real proof exists
9. Mobile-light — 3 sections hidden on mobile, MobileStickyCTA floats
10. Rate-limited demo — 3 calls/day client-side, 3/hour server-side
11. WhatsApp agents for personal use only — not customer-facing
12. Knowledge Base centralized — all agents read from one file
`;

export default KNOWLEDGE_BASE;
