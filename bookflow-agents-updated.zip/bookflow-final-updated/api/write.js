import Anthropic from '@anthropic-ai/sdk';
import { Redis } from '@upstash/redis';
import twilio from 'twilio';

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL,
  token: process.env.UPSTASH_REDIS_REST_TOKEN,
});
const twilioClient = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

const MY_NUMBER = process.env.MY_WHATSAPP_NUMBER;
const BOT_NUMBER = process.env.TWILIO_WHATSAPP_NUMBER;

// ─── KNOWLEDGE BASE (מהמסמך המלא) ───────────────────────────────────────────

const KB = `
== BOOKFLOW AI — FULL KNOWLEDGE BASE ==

--- PRODUCT ---
Name: BookFlow AI
Domain: bookflow-ai.com
Core promise: "You paid for that lead. By the time you picked up the phone, your competitor already closed them. BookFlow AI picks up every inbound lead — weekends, holidays, 3am — so you stop losing deals you already paid for."
Key stat: Calling a lead in <10 seconds converts up to 4x higher than calling after 30 minutes.
Setup time: 15 minutes, no developer needed.
Trial: 14 days, 60 minutes included, no credit card.

--- PRICING ---
Solo:       $99/mo  | 200 min | ~80–100 leads  | max bill $184
Business:   $349/mo | 500 min | ~200–250 leads | max bill $549  ⭐ MOST POPULAR
Agency:     $899/mo | 1,500 min | ~600–750 leads | max bill $1,299
Enterprise: $2,599/mo | 3,600 min | ~1,400–1,800 leads | max bill $3,599
Annual: 20% off. Hard caps — customer never billed over max. Ever.

--- TECH STACK (for dev context only) ---
Next.js 14 + TypeScript + Tailwind
Supabase (DB + Auth), Paddle (payments), ElevenLabs (voice demo), Retell AI (calls)
Vercel hosting, Resend (email), Google/Microsoft Calendar OAuth
CRMs: HubSpot, Salesforce, GoHighLevel

--- CUSTOMER AVATAR ---
Who: Business owner or sales manager, 32–55, male, US-based.
Pays $15–$80/lead via paid ads. Closer, not a marketer. Measures in deals + dollars.
Core pain: "I paid for that lead. I just couldn't get to the phone fast enough."
Money pain: Leads cost $15–80. When cold = money gone forever.
Time pain: Leads arrive nights/weekends — nobody there.
Competition pain: Competitor answered first = deal lost.
Emotional pain: Tired. Frustrated. Watches money walk out. Checks phone at 11pm.
Desire: Wake up to booked meetings. Flat predictable price. Never miss a lead.

--- BRAND VOICE ---
Direct. No fluff. Confident not arrogant. Empathetic. Urgent not pushy.
Short sentences. One idea per line. Write to ONE person, not a crowd.

Power words: every, instantly, never, while you sleep, already booked.
Loss frame > gain frame: "You're losing $X" beats "You'll save $X".
Always end with forward motion, not a summary.

--- COPY RULES ---
1. Lead with cost of inaction, not features.
2. Money math obvious and fast: "One deal/month pays for the whole year."
3. Speak to emotional exhaustion.
4. Use "every" constantly: Every lead. Every call. Every meeting.
5. Zero-risk language: "14-day free. Cancel in one click."
6. Contrast: Human setter $5k/mo, quits in 3mo. BookFlow $99/mo, 24/7, never quits.
7. End with forward motion: "What would 10 extra meetings do for your business?"

--- KEY MESSAGES ---
Hero line: "Every lead you don't call in 10 seconds is already talking to your competitor."
Pain: "You paid for that lead. By the time you picked up the phone, your competitor already closed them."
Solution: "BookFlow calls every lead the moment they fill out your form. While you sleep."
CTA: "Wake up tomorrow with meetings already booked."
ROI: "One extra deal per month pays for the entire year."

--- OBJECTION RESPONSES ---
"Too expensive" → One closed deal pays for the whole year. What's one deal worth?
"AI sounds robotic" → Most leads won't know. We disclose — required in most US states, actually builds trust.
"Leads hang up" → Hang-up rates lower than human SDRs. AI never sounds tired or pushy.
"We have a team" → Your team sleeps. Leads don't. BookFlow handles nights and weekends.
"Different from chatbots" → Real phone call in 10 seconds. Voice converts 3–5x better than chat.

--- COMPETITORS ---
Bland AI: $0.09/min, developer-only, hidden fees, no ready solution
Synthflow: $0.11/min, general platform, not appointment-focused
Retell AI: $0.07–0.31/min, developer API, healthcare-focused
Setter AI: $99/mo, similar but fewer features
Our edge: ready in 15 min + hard cap + live demo on homepage + no-code setup

--- TARGET AUDIENCES (priority) ---
#1 Solar Sales Manager — 35–50, TX/AZ/FL/CA, 300–2,000 leads/mo, deal $8–15K
    Pain: "400 Facebook leads this week. Team called 200. Other 200 went cold — $2M gone."
    Hook: "What happens to your leads after 6pm?"

#2 GoHighLevel Agency Owner — 28–42, remote, 10–80 clients, wants white-label
    Pain: "Clients ask why leads aren't converting. I need something I can resell."
    Hook: "Do your clients struggle with lead response time?"

#3 Mortgage Broker — 38–55, CA/FL/TX, 50–300 leads/mo, deal $3–8K
    Pain: "Lead fills 3 forms simultaneously. Whoever calls first wins."
    Hook: "Leads fill out 3 forms at once. Who calls them first?"

#4 Home Services (HVAC/Roofing) — 40–58, Midwest, 30–200 leads/mo, deal $5–50K
    Pain: "Team on roofs all day. Lead calls, nobody picks up. They book with competitor."
    Hook: "What happens when a lead calls while your team is on a job?"

--- MARKETING CHANNELS ---
Primary: LinkedIn DMs (10–15/day) — Solar first, then GHL, Mortgage, HVAC
Secondary: GoHighLevel Facebook community (100K+ members)
Content: 60-sec screen recording demos, no face needed
Demo offer: "Give me your phone — watch AI call you in 10 seconds" ($0.60 cost)
Trial offer: 5 real leads (NOT 200) — $3 total cost to you
Targets: 75 DMs/week → 7–14 replies → 2–4 demos → 1 paying customer/month

--- SOCIAL CONTENT STRATEGY ---
LinkedIn: 3x/week
  Monday: Demo video (screen recording, 60 sec, no face)
  Wednesday: Pain/stat post (100–150 words)
  Friday: ROI/case study post (when available)
Max 3 hashtags. No corporate speak. Hook in line 1.
Best times: 8–9am EST weekdays.

Hook formula: [Pain statement] → [Surprising stat] → [Implication] → CTA
`;

// ─── MARKETING AGENT SYSTEM PROMPT ───────────────────────────────────────────

const MARKETING_AGENT_PROMPT = `
אתה סוכן שיווקי אישי של מייסד BookFlow AI.
דבר עברית בלבד — אבל כתוב את כל התוכן השיווקי באנגלית מושלמת.

יש לך גישה מלאה ל-Knowledge Base של BookFlow:
${KB}

== יכולות ==

1. LINKEDIN DM
   פנייה קצרה לאיש קשר ספציפי.
   תבנית: פתח בכאב הספציפי שלו → שאלה אחת → רמז לפתרון → שאלה לסיום.
   אורך: 4–5 משפטים מקסימום. אל תזכיר מוצר בהודעה הראשונה.
   
2. LINKEDIN POST
   פוסט אורגני לפרופיל LinkedIn.
   Hook חייב להיות בשורה 1 — כאב או סטטיסטיקה מפתיעה.
   אורך: 100–200 מילים. מקסימום 3 hashtags בסוף.
   
3. FOLLOW-UP DM
   פולו-אפ לאחר 5 ימים ללא מענה.
   קצר. לא מתנצל. לא מוכר. פשוט מעלה שוב.
   
4. OBJECTION RESPONSE
   תשובה להתנגדות שקיבלת מליד.
   ישיר. תשתמש ב-objection responses מה-KB.
   
5. FACEBOOK GROUP POST
   פוסט לקבוצת GoHighLevel / Solar / Mortgage.
   תן ערך קודם. אל תמכור ישירות. הפתרון יציץ בסוף טבעי.
   
6. VIDEO SCRIPT
   סקריפט לסרטון הדגמה של 60 שניות.
   Hook 3 שניות → בעיה 10 שניות → הדגמה 35 שניות → CTA 12 שניות.

== כללים ==
- תמיד שאל: "לאיזה קהל?" אם לא צוין.
- תמיד כתוב 2 גרסאות — אחת ישירה יותר, אחת רכה יותר — ותסביר בעברית מה ההבדל.
- בסוף כל תוכן שאל: "רוצה שאשנה משהו? או לפרסם?"
- אם הוא אומר "פרסם" → [ACTION:{"type":"publish","content":"...","platform":"linkedin"}]
- אם הוא אומר "תזמן" → [ACTION:{"type":"schedule","content":"...","platform":"...","time":"..."}]
- שמור את כל התוכן שנוצר ב-Redis תחת 'content_library'
`;

// ─── DETECT COMMAND ───────────────────────────────────────────────────────────
function parseCommand(message) {
  const m = message.toLowerCase().trim();

  const types = [
    { key: 'dm', aliases: ['dm ', 'הודעה ', 'linkedin dm', 'פנייה '] },
    { key: 'post', aliases: ['post ', 'פוסט ', 'linkedin post'] },
    { key: 'followup', aliases: ['followup', 'פולו', 'follow up', 'follow-up'] },
    { key: 'objection', aliases: ['התנגדות', 'objection', 'ענה על'] },
    { key: 'facebook', aliases: ['facebook', 'fb ', 'קבוצה', 'group'] },
    { key: 'script', aliases: ['script', 'סקריפט', 'וידאו', 'video'] },
  ];

  for (const type of types) {
    if (type.aliases.some(a => m.includes(a))) {
      return type.key;
    }
  }
  return 'general';
}

function buildUserMessage(message, type, history) {
  const typeLabels = {
    dm: 'כתוב LinkedIn DM',
    post: 'כתוב LinkedIn Post',
    followup: 'כתוב Follow-up DM',
    objection: 'כתוב תשובה להתנגדות',
    facebook: 'כתוב פוסט לקבוצת Facebook',
    script: 'כתוב סקריפט לוידאו',
    general: 'בקשה שיווקית',
  };

  return `[${typeLabels[type]}]\n\n${message}`;
}

// ─── PROCESS PUBLISH ACTION ───────────────────────────────────────────────────
async function processAction(response) {
  const match = response.match(/\[ACTION:(.*?)\]/s);
  if (!match) return null;

  try {
    const action = JSON.parse(match[1].trim());

    // שמור ב-content library
    const library = await redis.get('content_library') || [];
    library.push({
      type: action.type,
      platform: action.platform,
      content: action.content,
      created: new Date().toISOString(),
      status: action.type === 'publish' ? 'published' : 'scheduled',
      scheduledTime: action.time || null,
    });
    await redis.set('content_library', library.slice(-50)); // שמור 50 אחרונים

    return action;
  } catch (e) {
    console.error('Action parse error:', e);
    return null;
  }
}

// ─── MAIN HANDLER ─────────────────────────────────────────────────────────────
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  if (req.body.From !== MY_NUMBER) return res.status(403).end();

  const rawMessage = req.body.Body?.trim();
  if (!rawMessage) return res.status(200).end();

  // הסר prefix /write או /w
  const message = rawMessage.replace(/^\/(write|w)\s*/i, '').trim();
  const commandType = parseCommand(message);

  try {
    // טען היסטוריה
    const history = await redis.get('marketing_history') || [];
    const recentHistory = history.slice(-8);

    // בנה הודעה
    const userMessage = buildUserMessage(message, commandType, recentHistory);

    const response = await anthropic.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 1200,
      system: MARKETING_AGENT_PROMPT,
      messages: [
        ...recentHistory,
        { role: 'user', content: userMessage },
      ],
    });

    let reply = response.content[0].text;

    // עבד פעולה אם יש
    const action = await processAction(reply);
    reply = reply.replace(/\[ACTION:.*?\]/gs, '').trim();

    // הוסף הודעת אישור פרסום
    let confirmMsg = '';
    if (action?.type === 'publish') {
      confirmMsg = `\n\n✅ נשמר ב-Content Library. כשתחבר LinkedIn/Buffer — יפורסם אוטומטית.`;
    } else if (action?.type === 'schedule') {
      confirmMsg = `\n\n📅 מתוזמן ל-${action.time || 'בקרוב'}.`;
    }

    // שמור היסטוריה
    const newHistory = [
      ...recentHistory,
      { role: 'user', content: userMessage },
      { role: 'assistant', content: reply },
    ].slice(-10);
    await redis.set('marketing_history', newHistory);

    // שלח תגובה
    const finalReply = `✍️ ${reply}${confirmMsg}`;

    // WhatsApp מוגבל ל-1600 תווים — חלק אם צריך
    if (finalReply.length <= 1500) {
      await twilioClient.messages.create({
        from: BOT_NUMBER,
        to: MY_NUMBER,
        body: finalReply,
      });
    } else {
      // שלח בשני חלקים
      const mid = Math.floor(finalReply.length / 2);
      const split = finalReply.lastIndexOf('\n', mid);
      await twilioClient.messages.create({ from: BOT_NUMBER, to: MY_NUMBER, body: finalReply.slice(0, split) });
      await new Promise(r => setTimeout(r, 500));
      await twilioClient.messages.create({ from: BOT_NUMBER, to: MY_NUMBER, body: finalReply.slice(split).trim() });
    }

    res.status(200).send('<Response></Response>');
  } catch (error) {
    console.error('Marketing agent error:', error);
    res.status(500).end();
  }
}
