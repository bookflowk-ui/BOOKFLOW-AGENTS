import { Redis } from '@upstash/redis';
import crypto from 'crypto';

const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL,
  token: process.env.UPSTASH_REDIS_REST_TOKEN,
});

// ─── VERIFY PADDLE SIGNATURE ──────────────────────────────────────────────────
function verifyPaddleSignature(rawBody, signature, secret) {
  try {
    const hmac = crypto.createHmac('sha256', secret);
    hmac.update(rawBody);
    const expected = hmac.digest('hex');
    return crypto.timingSafeEqual(
      Buffer.from(signature),
      Buffer.from(expected)
    );
  } catch {
    return false;
  }
}

// ─── VERIFY STRIPE SIGNATURE ─────────────────────────────────────────────────
function verifyStripeSignature(rawBody, signature, secret) {
  try {
    const parts = signature.split(',');
    const timestamp = parts.find(p => p.startsWith('t=')).split('=')[1];
    const sig = parts.find(p => p.startsWith('v1=')).split('=')[1];
    const payload = `${timestamp}.${rawBody}`;
    const hmac = crypto.createHmac('sha256', secret);
    hmac.update(payload);
    const expected = hmac.digest('hex');
    return crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected));
  } catch {
    return false;
  }
}

// ─── LOAD/SAVE FINANCIALS ─────────────────────────────────────────────────────
async function loadFinancials() {
  try {
    return await redis.get('financials') || {
      subscriptions: [],  // לקוחות פעילים
      transactions: [],   // כל העסקאות
      expenses: [],       // הוצאות ידניות
      mrr: 0,
      lastUpdated: null,
    };
  } catch {
    return { subscriptions: [], transactions: [], expenses: [], mrr: 0, lastUpdated: null };
  }
}

async function saveFinancials(data) {
  data.lastUpdated = Date.now();
  await redis.set('financials', data);
}

// ─── PROCESS PADDLE EVENT ─────────────────────────────────────────────────────
async function processPaddleEvent(event, data) {
  const fin = await loadFinancials();

  switch (event) {
    case 'subscription.created':
    case 'subscription.activated': {
      const sub = {
        id: data.id,
        customerId: data.customer_id,
        email: data.customer?.email || '',
        plan: data.items?.[0]?.price?.name || 'Unknown',
        amount: data.items?.[0]?.price?.unit_price?.amount / 100 || 0,
        currency: data.currency_code || 'USD',
        status: 'active',
        startDate: data.started_at || new Date().toISOString(),
        source: 'paddle',
      };
      fin.subscriptions.push(sub);
      fin.transactions.push({
        type: 'subscription_new',
        amount: sub.amount,
        description: `לקוח חדש — ${sub.plan}`,
        email: sub.email,
        date: sub.startDate,
      });
      break;
    }

    case 'subscription.canceled':
    case 'subscription.paused': {
      const idx = fin.subscriptions.findIndex(s => s.id === data.id);
      if (idx > -1) {
        fin.transactions.push({
          type: 'subscription_cancel',
          amount: -fin.subscriptions[idx].amount,
          description: `ביטול — ${fin.subscriptions[idx].plan}`,
          email: fin.subscriptions[idx].email,
          date: new Date().toISOString(),
        });
        fin.subscriptions.splice(idx, 1);
      }
      break;
    }

    case 'transaction.completed': {
      fin.transactions.push({
        type: 'payment',
        amount: data.details?.totals?.grand_total / 100 || 0,
        description: data.items?.[0]?.price?.name || 'תשלום',
        email: data.customer?.email || '',
        date: data.created_at || new Date().toISOString(),
        source: 'paddle',
      });
      break;
    }
  }

  // חשב MRR מחדש
  fin.mrr = fin.subscriptions
    .filter(s => s.status === 'active')
    .reduce((sum, s) => sum + s.amount, 0);

  await saveFinancials(fin);
  return fin;
}

// ─── PROCESS STRIPE EVENT ─────────────────────────────────────────────────────
async function processStripeEvent(event, data) {
  const fin = await loadFinancials();

  switch (event) {
    case 'customer.subscription.created':
    case 'customer.subscription.updated': {
      const amount = data.items?.data?.[0]?.price?.unit_amount / 100 || 0;
      const existing = fin.subscriptions.findIndex(s => s.id === data.id);
      const sub = {
        id: data.id,
        customerId: data.customer,
        email: data.metadata?.email || '',
        plan: data.items?.data?.[0]?.price?.nickname || 'Unknown',
        amount,
        currency: data.currency?.toUpperCase() || 'USD',
        status: data.status === 'active' ? 'active' : 'inactive',
        startDate: new Date(data.start_date * 1000).toISOString(),
        source: 'stripe',
      };
      if (existing > -1) fin.subscriptions[existing] = sub;
      else {
        fin.subscriptions.push(sub);
        fin.transactions.push({
          type: 'subscription_new',
          amount,
          description: `לקוח חדש — ${sub.plan}`,
          email: sub.email,
          date: sub.startDate,
        });
      }
      break;
    }

    case 'customer.subscription.deleted': {
      const idx = fin.subscriptions.findIndex(s => s.id === data.id);
      if (idx > -1) {
        fin.transactions.push({
          type: 'subscription_cancel',
          amount: -fin.subscriptions[idx].amount,
          description: `ביטול — ${fin.subscriptions[idx].plan}`,
          email: fin.subscriptions[idx].email,
          date: new Date().toISOString(),
        });
        fin.subscriptions.splice(idx, 1);
      }
      break;
    }

    case 'invoice.payment_succeeded': {
      fin.transactions.push({
        type: 'payment',
        amount: data.amount_paid / 100,
        description: data.lines?.data?.[0]?.description || 'תשלום',
        email: data.customer_email || '',
        date: new Date(data.created * 1000).toISOString(),
        source: 'stripe',
      });
      break;
    }
  }

  fin.mrr = fin.subscriptions
    .filter(s => s.status === 'active')
    .reduce((sum, s) => sum + s.amount, 0);

  await saveFinancials(fin);
  return fin;
}

// ─── MAIN HANDLER ─────────────────────────────────────────────────────────────
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const rawBody = JSON.stringify(req.body);
  const source = req.headers['paddle-signature'] ? 'paddle' : 'stripe';

  // אימות חתימה
  if (source === 'paddle') {
    const sig = req.headers['paddle-signature'];
    if (!verifyPaddleSignature(rawBody, sig, process.env.PADDLE_WEBHOOK_SECRET)) {
      console.error('Invalid Paddle signature');
      return res.status(401).end();
    }
    const { event_type, data } = req.body;
    await processPaddleEvent(event_type, data);
  } else {
    const sig = req.headers['stripe-signature'];
    if (!verifyStripeSignature(rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET)) {
      console.error('Invalid Stripe signature');
      return res.status(401).end();
    }
    const { type, data } = req.body;
    await processStripeEvent(type, data?.object);
  }

  res.status(200).json({ received: true });
}
