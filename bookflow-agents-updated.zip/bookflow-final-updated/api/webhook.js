import Anthropic from '@anthropic-ai/sdk';
import { Redis } from '@upstash/redis';
import twilio from 'twilio';
import { KNOWLEDGE_BASE } from '../knowledge.js';
import { publishContent } from '../publisher.js';

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL,
  token: process.env.UPSTASH_REDIS_REST_TOKEN,
});
const twilioClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

const MY_NUMBER = process.env.MY_WHATSAPP_NUMBER;
const BOT_NUMBER = process.env.TWILIO_WHATSAPP_NUMBER;

// ─── LOAD KNOWLEDGE (from Redis or default) ───────────────────────────────────
async function getKnowledge() {
  try {
    const custom = await redis.get('knowledge_base');
    return custom || KNOWLEDGE_BASE;
  } catch {
    return KNOWLEDGE_BASE;
  }
}

// ─── AGENT PROMPTS ────────────────────────────────────────────────────────────
function buildAgents(kb) {
  const base = `
אתה עוזר אישי של מייסד BookFlow AI. דבר עברית בלבד. קצר וישיר.
הנה כל מה שאתה צריך לדעת על העסק:

${kb}
`;

  return {
    task: `${base}
תפקידך: ניהול משימות ותזכורות.
- הוספה → [ACTION:{"type":"add_task","text":"..."}]
- בוצע → [ACTION:{"type":"done","index":N}]
- מחיקה → [ACTION:{"type":"delete","index":N}]
- ניקוי → [ACTION:{"type":"clear"}]
תאשר קצר. הצג רשימה עם מספרים.`,

    write: `${base}
תפקידך: כתיבת תוכן שיווקי באנגלית מושלמת.
כתוב לפי Brand Voice מה-Knowledge Base.
סוגי תוכן:
- LinkedIn DM: פנייה קצרה, מתחיל בכאב, מסתיים בשאלה
- LinkedIn Post: hook חזק, 150-250 מילים, max 3 hashtags
- פוסט Instagram/Facebook: קצר יותר, יותר ויזואלי בשפה
- TikTok script: hook 3 שניות, גוף 30 שניות, CTA
- Script להדגמה: מה לומר בסרטון 60 שניות

אחרי כל תוכן שכתבת, שאל: "לפרסם עכשיו? ענה: linkedin / fb / ig / buffer / לא"
אם הוא אומר לפרסם → [ACTION:{"type":"publish","content":"...","platforms":["linkedin"]}]`,

    advise: `${base}
תפקידך: יועץ עסקי אישי שמכיר את BookFlow לעומק.
תן תשובות קצרות עם מספרים קונקרטיים.
אם שואלים "מה אני עושה היום" — 3 פעולות ספציפיות.
אם שואלים על אסטרטגיה — השווה אפשרויות עם מחיר/תועלת.
דבר כמו שותף עסקי, לא כמו עוזר.`,

    pipeline: `${base}
תפקידך: ניהול pipeline ולקוחות.
- הוסף ליד → [ACTION:{"type":"add_lead","name":"...","status":"contacted","notes":"..."}]
- עדכן → [ACTION:{"type":"update_lead","name":"...","status":"...","notes":"..."}]
- מחק → [ACTION:{"type":"delete_lead","name":"..."}]
סטטוסים: contacted | replied | demo_scheduled | trial | paying | lost
תמיד אמור כמה לידים פעילים יש.`,

    finance: `${base}
תפקידך: CFO אישי עם גישה לנתונים פיננסיים בזמן אמת.
- הוצאה ידנית → [ACTION:{"type":"add_expense","category":"...","amount":X,"description":"..."}]
קטגוריות: infrastructure | marketing | tools | telephony | ai_costs | other
תחזית: חשב כמה לקוחות צריך לפי המודל הפיננסי מה-KB.
תן מספרים ברורים. לא יועמ"שי.`,

    kb: `${base}
תפקידך: ניהול ה-Knowledge Base.
פקודות:
- הצג קטע → הצג את החלק המבוקש מה-KB
- עדכן → [ACTION:{"type":"update_kb","section":"...","content":"..."}]
- רענן → [ACTION:{"type":"reset_kb"}]
ה-KB מכיל את כל הידע על המוצר, קהלי יעד, מחירים, brand voice ועוד.`,
  };
}

// ─── DETECT AGENT ─────────────────────────────────────────────────────────────
function detectAgent(msg) {
  const m = msg.toLowerCase().trim();
  if (m.startsWith('/task') || m.startsWith('/t ')) return 'task';
  if (m.startsWith('/write') || m.startsWith('/w ')) return 'write';
  if (m.startsWith('/advise') || m.startsWith('/a ')) return 'advise';
  if (m.startsWith('/pipeline') || m.startsWith('/p ')) return 'pipeline';
  if (m.startsWith('/finance') || m.startsWith('/f ')) return 'finance';
  if (m.startsWith('/kb')) return 'kb';
  return 'advise';
}

function stripPrefix(msg) {
  return msg.replace(/^\/(task|write|advise|pipeline|finance|kb|t|w|a|p|f)\s*/i, '').trim();
}

// ─── LOAD STATE ───────────────────────────────────────────────────────────────
async function loadState() {
  try {
    return {
      tasks: await redis.get('tasks') || [],
      pipeline: await redis.get('pipeline') || [],
      history: await redis.get('chat_history') || [],
      financials: await redis.get('financials') || { subscriptions: [], transactions: [], expenses: [], mrr: 0 },
    };
  } catch {
    return { tasks: [], pipeline: [], history: [], financials: { subscriptions: [], transactions: [], expenses: [], mrr: 0 } };
  }
}

// ─── PROCESS ACTIONS ──────────────────────────────────────────────────────────
async function processActions(response, state) {
  const matches = [...response.matchAll(/\[ACTION:(.*?)\]/gs)];
  for (const match of matches) {
    try {
      const action = JSON.parse(match[1].trim());
      const { tasks, pipeline, financials } = state;

      switch (action.type) {
        case 'add_task':
          tasks.push({ text: action.text, done: false, created: Date.now() });
          await redis.set('tasks', tasks); break;
        case 'done':
          if (tasks[action.index]) { tasks[action.index].done = true; await redis.set('tasks', tasks); } break;
        case 'delete':
          tasks.splice(action.index, 1); await redis.set('tasks', tasks); break;
        case 'clear':
          await redis.set('tasks', []); break;

        case 'add_lead':
          pipeline.push({ name: action.name, status: action.status || 'contacted', notes: action.notes || '', updated: Date.now() });
          await redis.set('pipeline', pipeline); break;
        case 'update_lead': {
          const l = pipeline.find(x => x.name.toLowerCase().includes(action.name.toLowerCase()));
          if (l) { l.status = action.status; l.updated = Date.now(); if (action.notes) l.notes = action.notes; await redis.set('pipeline', pipeline); }
          break;
        }
        case 'delete_lead': {
          const i = pipeline.findIndex(x => x.name.toLowerCase().includes(action.name.toLowerCase()));
          if (i > -1) { pipeline.splice(i, 1); await redis.set('pipeline', pipeline); }
          break;
        }

        case 'add_expense':
          financials.expenses.push({ category: action.category, amount: action.amount, description: action.description || '', date: new Date().toISOString() });
          await redis.set('financials', financials); break;

        case 'publish': {
          const platforms = action.platforms || ['linkedin'];
          const results = await publishContent(action.content, 'linkedin_now', platforms);
          const summary = results.map(r => `${r.platform}: ${r.status}`).join(', ');
          await twilioClient.messages.create({ from: BOT_NUMBER, to: MY_NUMBER, body: `📤 פורסם — ${summary}` });
          break;
        }

        case 'update_kb':
          await redis.set(`kb_section_${action.section}`, action.content);
          break;
        case 'reset_kb':
          await redis.del('knowledge_base');
          break;
      }
    } catch (e) { console.error('Action error:', e); }
  }
}

// ─── MORNING BRIEFING (called from cron) ─────────────────────────────────────
export async function sendMorningBriefing() {
  try {
    const state = await loadState();
    const { tasks, pipeline, financials } = state;
    const openTasks = tasks.filter(t => !t.done);
    const hotLeads = pipeline.filter(l => ['replied', 'demo_scheduled', 'trial'].includes(l.status));
    const stale = pipeline.filter(l => l.status === 'contacted' && Date.now() - l.updated > 3 * 24 * 60 * 60 * 1000);

    const now = new Date();
    const m = now.getMonth(), y = now.getFullYear();
    const rev = financials.transactions.filter(t => { const d = new Date(t.date); return d.getMonth() === m && d.getFullYear() === y && t.amount > 0; }).reduce((s, t) => s + t.amount, 0);
    const exp = financials.expenses.filter(e => { const d = new Date(e.date); return d.getMonth() === m && d.getFullYear() === y; }).reduce((s, e) => s + e.amount, 0);

    let msg = `☀️ *בוקר טוב!*\n\n`;
    msg += `💰 MRR: *$${financials.mrr.toFixed(0)}* | החודש: $${rev.toFixed(0)} in / $${exp.toFixed(0)} out | נטו: *$${(rev - exp).toFixed(0)}*\n`;
    msg += `👥 לקוחות פעילים: ${financials.subscriptions.filter(s => s.status === 'active').length}\n\n`;
    if (openTasks.length) { msg += `📋 *משימות (${openTasks.length}):*\n`; openTasks.forEach((t, i) => { msg += `${i + 1}. ${t.text}\n`; }); msg += '\n'; }
    if (hotLeads.length) { msg += `🔥 *לידים חמים:* ${hotLeads.map(l => l.name).join(', ')}\n`; }
    if (stale.length) { msg += `⏰ *פולו-אפ נדרש:* ${stale.map(l => l.name).join(', ')}\n`; }
    msg += `\n_/task /write /advise /pipeline /finance /kb_`;

    await twilioClient.messages.create({ from: BOT_NUMBER, to: MY_NUMBER, body: msg });
  } catch (e) { console.error('Briefing error:', e); }
}

// ─── MAIN WEBHOOK ─────────────────────────────────────────────────────────────
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  if (req.body.From !== MY_NUMBER) return res.status(403).end();

  const rawMessage = req.body.Body?.trim();
  if (!rawMessage) return res.status(200).end();

  try {
    const agentType = detectAgent(rawMessage);
    const message = stripPrefix(rawMessage);
    const state = await loadState();
    const { tasks, pipeline, financials, history } = state;
    const kb = await getKnowledge();
    const AGENTS = buildAgents(kb);

    // Context per agent
    const now = new Date();
    const mo = now.getMonth(), yr = now.getFullYear();
    const monthRev = financials.transactions.filter(t => { const d = new Date(t.date); return d.getMonth() === mo && d.getFullYear() === yr && t.amount > 0; }).reduce((s, t) => s + t.amount, 0);
    const monthExp = financials.expenses.filter(e => { const d = new Date(e.date); return d.getMonth() === mo && d.getFullYear() === yr; }).reduce((s, e) => s + e.amount, 0);

    const contexts = {
      task: `\nמשימות:\n${tasks.map((t, i) => `${i + 1}. ${t.done ? '✅' : '⬜'} ${t.text}`).join('\n') || 'אין'}`,
      pipeline: `\nPipeline:\n${pipeline.map(l => `• ${l.name} — ${l.status}${l.notes ? ` (${l.notes})` : ''}`).join('\n') || 'ריק'}`,
      finance: `\nנתונים פיננסיים:\nMRR: $${financials.mrr.toFixed(0)}\nלקוחות: ${financials.subscriptions.filter(s => s.status === 'active').length}\nהכנסות החודש: $${monthRev.toFixed(0)}\nהוצאות: $${monthExp.toFixed(0)}\nנטו: $${(monthRev - monthExp).toFixed(0)}\nהוצאות: ${JSON.stringify(financials.expenses.reduce((a, e) => { a[e.category] = (a[e.category] || 0) + e.amount; return a; }, {}))}`,
      write: '',
      advise: '',
      kb: `\nKB נוכחי:\n${kb.slice(0, 500)}...`,
    };

    const recentHistory = history.slice(-6);
    const messages = [
      ...recentHistory,
      { role: 'user', content: message + (contexts[agentType] || '') },
    ];

    const model = ['task', 'pipeline'].includes(agentType)
      ? 'claude-haiku-4-5-20251001'
      : 'claude-sonnet-4-6';

    const response = await anthropic.messages.create({
      model,
      max_tokens: 1000,
      system: AGENTS[agentType],
      messages,
    });

    let reply = response.content[0].text;
    await processActions(reply, state);
    reply = reply.replace(/\[ACTION:.*?\]/gs, '').trim();

    const newHistory = [...recentHistory, { role: 'user', content: message }, { role: 'assistant', content: reply }].slice(-10);
    await redis.set('chat_history', newHistory);

    const emoji = { task: '📋', write: '✍️', advise: '💡', pipeline: '🎯', finance: '💰', kb: '🧠' };
    await twilioClient.messages.create({ from: BOT_NUMBER, to: MY_NUMBER, body: `${emoji[agentType]} ${reply}` });
    res.status(200).send('<Response></Response>');
  } catch (e) {
    console.error('Error:', e);
    res.status(500).end();
  }
}
