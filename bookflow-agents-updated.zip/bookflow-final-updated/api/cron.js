import { sendMorningBriefing } from './webhook.js';

export default async function handler(req, res) {
  if (req.headers.authorization !== `Bearer ${process.env.CRON_SECRET}`) {
    return res.status(401).end();
  }
  await sendMorningBriefing();
  res.status(200).json({ ok: true });
}
