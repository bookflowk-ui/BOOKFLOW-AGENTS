// ============================================================
// BOOKFLOW AI — KNOWLEDGE BASE
// כל הסוכנים קוראים מכאן. עדכן פה = כל הסוכנים מתעדכנים.
// לעדכן דרך וואצאפ: /kb update [section] [content]
// ============================================================

export const KNOWLEDGE_BASE = `
== BOOKFLOW AI — KNOWLEDGE BASE ==
Last updated: auto

--- PRODUCT ---
Name: BookFlow AI
Website: bookflow-ai.com
Description: AI that calls every inbound lead within 10 seconds, handles objections, and books meetings automatically into the calendar.
Core promise: Never miss a lead. Never lose a deal because of response time.
Setup time: 15 minutes, no developer needed.
Key differentiator: Hard monthly bill cap — no surprise overages, ever.

--- PRICING ---
Solo:      $149/mo | 200 min | ~80-100 leads  | 1 agent    | Google Calendar + basic analytics
Business:  $349/mo | 500 min | ~200-250 leads | Unlimited  | GoHighLevel + WhatsApp confirmation + Slack support
Agency:    $899/mo | 1,500 min | ~600-750 leads | White-label + voice cloning + dedicated AM
Enterprise:$2,599/mo | 3,600 min | ~1,400-1,800 leads | Custom pools + SLA + DPAs
Pay-per-use: $0.45/min (no commitment)
Free trial: 14 days, 60 minutes, no credit card.

--- UNIT ECONOMICS ---
Cost per minute: $0.20
Gross margin at base: ~70%
Break-even for $10K/month salary: 48 Business customers
MRR at 100 customers (avg $800): ~$80,000

--- TARGET AVATARS ---
#1 Marcus — Solar Sales Manager, 35-50, TX/AZ/FL, 300-2000 leads/mo, deal value $8-15K
#2 Jason — GoHighLevel Agency Owner, 28-42, remote, 10-80 clients, wants white-label to resell
#3 David — Mortgage Broker, 38-55, CA/FL, 50-300 leads/mo, deal value $3-8K  
#4 Tony — HVAC/Roofing Owner, 40-58, Midwest, 30-200 leads/mo, team in field can't answer phone

--- PAINS (universal) ---
- Pays $15-80/lead and loses them because nobody called fast enough
- Human SDR costs $5,000+/mo, quits after 3 months, has bad days
- Leads fill 3 forms simultaneously — whoever calls first wins
- Leads come in at 11pm on Sunday — nobody there
- No visibility into how many leads slipped through
- Campaign goes viral → team overwhelmed → leads lost

--- DESIRES ---
- Wake up to booked meetings without doing anything
- Never depend on people who quit, get sick, have bad days
- Pay one flat predictable price
- See every conversation — what was said, what was booked
- Compete with bigger companies on response speed

--- BRAND VOICE ---
Direct. No fluff. Confident but not arrogant. Empathetic.
Short sentences. One idea per line.
Write to ONE person, not a crowd.
Power words: every, instantly, never, while you sleep, already.
Loss frame over gain frame: "You're losing $X" > "You'll save $X"

--- KEY MESSAGES ---
Hero: "Every lead you don't call in 10 seconds is already talking to your competitor."
Pain: "You paid for that lead. By the time you picked up the phone, your competitor already closed them."
Solution: "BookFlow calls every lead the moment they fill out your form. While you sleep."
CTA: "Wake up tomorrow with meetings already booked."
Proof: "One extra deal per month pays for the entire year."

--- OBJECTION HANDLING ---
"Too expensive" → One deal pays for the whole year. What's one deal worth to you?
"Will leads know it's AI?" → Most won't. We disclose anyway — required in most US states, builds trust.
"What if they hang up?" → Hang-up rates are lower than human SDR calls. AI never sounds tired or pushy.
"How is this different from chatbots?" → Real phone call in 10 seconds. Voice converts 3-5x better than chat.
"We already have a team" → Your team sleeps. Leads don't. BookFlow handles nights and weekends.

--- COMPETITORS ---
Bland AI: $0.09/min — developer-only, no ready solution, hidden fees
Synthflow: $0.11/min — general platform, not appointment-focused
Retell AI: $0.07-0.31/min — developer API, healthcare-focused
Setter AI: $99/mo — similar but fewer features, less polished
Our edge: ready solution in 15 min + hard cap + live demo on homepage + no-code

--- MARKETING STRATEGY ---
Primary: LinkedIn DMs (10-15/day) to Solar, GHL, Mortgage
Secondary: GoHighLevel Facebook community (100K+ members)  
Content: 60-sec screen recording demos, no face needed
Demo offer: "Give me your phone number — watch AI call you in 10 seconds" ($0.60 cost)
Trial offer: 5 real leads (not 200) — $3 total cost
Weekly targets: 75 DMs → 7-14 replies → 2-4 demos → 1 paying customer

--- SOCIAL MEDIA STRATEGY ---
LinkedIn: 3x/week — Monday demo video, Wednesday pain post, Friday case study
Tone: Direct, no hashtag spam, max 3 hashtags
Hook formula: Pain statement → stat → solution tease → CTA
Best times: 8-9am EST weekdays
`;

export default KNOWLEDGE_BASE;
