// ============================================================
// SOCIAL MEDIA PUBLISHER
// מפרסם ל-LinkedIn ישירות + מתזמן ל-Buffer (FB/IG/TikTok)
// ============================================================

// ─── LINKEDIN DIRECT POST ────────────────────────────────────────────────────
export async function postToLinkedIn(content, accessToken, personUrn) {
  const body = {
    author: `urn:li:person:${personUrn}`,
    lifecycleState: 'PUBLISHED',
    specificContent: {
      'com.linkedin.ugc.ShareContent': {
        shareCommentary: { text: content },
        shareMediaCategory: 'NONE',
      },
    },
    visibility: { 'com.linkedin.ugc.MemberNetworkVisibility': 'PUBLIC' },
  };

  const res = await fetch('https://api.linkedin.com/v2/ugcPosts', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
      'X-Restli-Protocol-Version': '2.0.0',
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`LinkedIn post failed: ${err}`);
  }
  return await res.json();
}

// ─── BUFFER SCHEDULE ─────────────────────────────────────────────────────────
export async function scheduleToBuffer(content, platforms, scheduledAt = null) {
  // platforms: array of Buffer profile IDs
  // scheduledAt: ISO string or null (null = add to queue)

  const body = {
    text: content,
    profile_ids: platforms,
    ...(scheduledAt && { scheduled_at: scheduledAt }),
  };

  const res = await fetch('https://api.bufferapp.com/1/updates/create.json', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${process.env.BUFFER_ACCESS_TOKEN}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Buffer schedule failed: ${err}`);
  }
  return await res.json();
}

// ─── PUBLISH HANDLER ─────────────────────────────────────────────────────────
// action: 'linkedin_now' | 'buffer_queue' | 'buffer_schedule'
// platforms: ['linkedin', 'facebook', 'instagram', 'tiktok']
export async function publishContent(content, action, platforms = [], scheduledAt = null) {
  const results = [];

  if (action === 'linkedin_now' || platforms.includes('linkedin')) {
    if (process.env.LINKEDIN_ACCESS_TOKEN && process.env.LINKEDIN_PERSON_URN) {
      try {
        const r = await postToLinkedIn(
          content,
          process.env.LINKEDIN_ACCESS_TOKEN,
          process.env.LINKEDIN_PERSON_URN
        );
        results.push({ platform: 'linkedin', status: 'published', id: r.id });
      } catch (e) {
        results.push({ platform: 'linkedin', status: 'error', error: e.message });
      }
    }
  }

  const bufferPlatforms = platforms.filter(p => p !== 'linkedin');
  if (bufferPlatforms.length > 0 && process.env.BUFFER_ACCESS_TOKEN) {
    const profileIds = bufferPlatforms.map(p => process.env[`BUFFER_PROFILE_${p.toUpperCase()}`]).filter(Boolean);
    if (profileIds.length > 0) {
      try {
        await scheduleToBuffer(content, profileIds, scheduledAt);
        results.push({ platform: bufferPlatforms.join('+'), status: action === 'buffer_schedule' ? 'scheduled' : 'queued' });
      } catch (e) {
        results.push({ platform: 'buffer', status: 'error', error: e.message });
      }
    }
  }

  return results;
}
